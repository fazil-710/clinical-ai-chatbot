def test_health_endpoint_returns_ok(client):
    test_client, _ = client
    response = test_client.get("/health")

    assert response.status_code == 200
    data = response.get_json()
    assert data["ok"] is True
    assert data["service"] == "healthy-clinic-chatbot"
    assert data["version"] == "test-version"
    assert "timestamp_utc" in data


def test_chat_rejects_empty_message(client):
    test_client, _ = client
    response = test_client.post("/chat", json={"message": "   "})

    assert response.status_code == 400
    data = response.get_json()
    assert data["ok"] is False
    assert "enter a message" in data["error"].lower()


def test_chat_rejects_too_long_message(client):
    test_client, _ = client
    long_message = "a" * 51
    response = test_client.post("/chat", json={"message": long_message})

    assert response.status_code == 413
    data = response.get_json()
    assert data["ok"] is False
    assert "too long" in data["error"].lower()


def test_chat_success_uses_reply_function(client, monkeypatch):
    test_client, app_module = client

    def fake_get_ai_reply(user_message, channel, conversation_id):
        assert user_message == "Hello"
        assert channel == "web"
        assert conversation_id == "session-1"
        return "Hi from test bot"

    monkeypatch.setattr(app_module, "get_ai_reply", fake_get_ai_reply)

    response = test_client.post(
        "/chat",
        json={"message": "Hello", "conversation_id": "session-1"},
    )

    assert response.status_code == 200
    data = response.get_json()
    assert data["ok"] is True
    assert data["reply"] == "Hi from test bot"
    assert data["conversation_id"] == "session-1"
