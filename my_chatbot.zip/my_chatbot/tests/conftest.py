import importlib

import pytest


@pytest.fixture()
def client(monkeypatch, tmp_path):
    monkeypatch.setenv("GROQ_API_KEY", "test-key")
    monkeypatch.setenv("DATABASE_PATH", str(tmp_path / "test_chat_history.db"))
    monkeypatch.setenv("MAX_MESSAGE_LENGTH", "50")
    monkeypatch.setenv("APP_VERSION", "test-version")

    app_module = importlib.import_module("app")
    app_module = importlib.reload(app_module)

    app_module.app.config["TESTING"] = True
    with app_module.app.test_client() as test_client:
        yield test_client, app_module
